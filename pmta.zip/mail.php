﻿<?php
$data = $_GET;
$data['ip'] = $_SERVER['REMOTE_ADDR'];
    $myCurl = curl_init();
  curl_setopt_array($myCurl, array(
      CURLOPT_URL => 'http://xspamer.com/interface/stat.ashx?',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_POST => true,
      CURLOPT_POSTFIELDS => http_build_query($data)
  ));
  $result = curl_exec($myCurl);
  
	header('Content-Type: image/png');
	echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABAQMAAAAl21bKAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAApJREFUCNdjYAAAAAIAAeIhvDMAAAAASUVORK5CYII=');
?>