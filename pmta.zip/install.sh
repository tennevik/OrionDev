#!/bin/bash

cat << 'EOF'
╔══╗╔╗╔╗╔════╗╔══╗────╔══╗╔══╗╔═══╗╔══╗╔═══╗╔════╗
║╔╗║║║║║╚═╗╔═╝║╔╗║────║╔═╝║╔═╝║╔═╗║╚╗╔╝║╔═╗║╚═╗╔═╝
║╚╝║║║║║──║║──║║║║╔══╗║╚═╗║║──║╚═╝║─║║─║╚═╝║──║║
║╔╗║║║║║──║║──║║║║╚══╝╚═╗║║║──║╔╗╔╝─║║─║╔══╝──║║
║║║║║╚╝║──║║──║╚╝║────╔═╝║║╚═╗║║║║─╔╝╚╗║║─────║║
╚╝╚╝╚══╝──╚╝──╚══╝────╚══╝╚══╝╚╝╚╝─╚══╝╚╝─────╚╝
╔╗╔╗───╔╗──╔══╗
║║║║──╔╝║──║╔╗║
║║║║──╚╗║──║║║║
║╚╝║───║║──║║║║
╚╗╔╝╔╗─║║╔╗║╚╝║
─╚╝─╚╝─╚╝╚╝╚══╝
─╔╗
╔╝╚╗
╚╗╔╝
─╚╝
╔═══╗╔══╗╔╗╔╗╔╗╔═══╗╔═══╗╔╗──╔╗╔════╗╔══╗
║╔═╗║║╔╗║║║║║║║║╔══╝║╔═╗║║║──║║╚═╗╔═╝║╔╗║
║╚═╝║║║║║║║║║║║║╚══╗║╚═╝║║╚╗╔╝║──║║──║╚╝║
║╔══╝║║║║║║║║║║║╔══╝║╔╗╔╝║╔╗╔╗║──║║──║╔╗║
║║───║╚╝║║╚╝╚╝║║╚══╗║║║║─║║╚╝║║──║║──║║║║
╚╝───╚══╝╚═╝╚═╝╚═══╝╚╝╚╝─╚╝──╚╝──╚╝──╚╝╚╝
╔╗╔╗──╔══╗
║║║║──║╔═╝
║╚╝║──║╚═╗
╚═╗║──╚═╗║
──║║╔╗╔═╝║
──╚╝╚╝╚══╝                       
EOF


###################################################################################
#Install LAMP

echo "Auto-Script версии 1.0"
echo "Номер лицензии: 0000"
echo "Установка началась. Ожидайте..."
yum -y update >/dev/null 2>/dev/null
service iptables stop >/dev/null 2>/dev/null
chkconfig iptables off >/dev/null 2>/dev/null
echo "Update instalation repositories successfull"
echo "Start installing LAMP"
yum -y install httpd >/dev/null 2>/dev/null
chkconfig httpd on && service httpd start
rm /tmp/vh >/dev/null 2>/dev/null
while read line
do
echo $line > /tmp/vline
echo "#`cat /tmp/vline | awk '{print $1}'`">> /tmp/vh
echo "NameVirtualHost `cat /tmp/vline | awk '{print $2}'`">> /tmp/vh
echo "<VirtualHost `cat /tmp/vline | awk '{print $1}'`>">> /tmp/vh
echo "DocumentRoot /var/www/`cat /tmp/vline | awk '{print $1}'`" >> /tmp/vh
echo "ServerName `cat /tmp/vline| awk '{print $1}'`" >> /tmp/vh
echo "</VirtualHost>">> /tmp/vh
echo " ">> /tmp/vh
done < /root/domains.txt
cat /tmp/vh >> /etc/httpd/conf/httpd.conf
cat << 'EOF' >> /etc/httpd/conf/httpd.conf
<Directory />
    Options FollowSymLinks
    AllowOverride All
    Allow from All
</Directory>
EOF
service httpd start
echo "Apache install successfull"
yum -y install mysql-server >/dev/null 2>/dev/null
chkconfig mysqld on && service mysqld start
echo "MySQL install successfull"
yum -y install php php-mysql php-pear* php-common php-mbstring php-mcrypt php-devel php-xml php-gd php-intl>/dev/null 2>/dev/null
echo "PHP install successfull"
echo "LAMP install successfull"
sleep 1

####################################################################################
#Install Postfix
echo "Start installing & configuring Postfix"
groupadd vmail -g 2222 >/dev/null 2>/dev/null
useradd vmail -r -g 2222 -u 2222 -d /var/vmail -m -c "My Email user" >/dev/null 2>/dev/null
yum -y remove exim sendmail >/dev/null 2>/dev/null
yum -y install postfix cronie >/dev/null 2>/dev/null
cp /etc/postfix/main.cf{,.orig}
cat <<'EOF' > /etc/postfix/main.cf
queue_directory = /var/spool/postfix
command_directory = /usr/sbin
daemon_directory = /usr/libexec/postfix
data_directory = /var/lib/postfix
mail_owner = postfix
unknown_local_recipient_reject_code = 550
alias_maps = hash:/etc/postfix/aliases
alias_database = $alias_maps
 
inet_interfaces = all
inet_protocols = ipv4
mydestination = 
 
debug_peer_level = 2
debugger_command =
         PATH=/bin:/usr/bin:/usr/local/bin:/usr/X11R6/bin
         ddd $daemon_directory/$process_name $process_id & sleep 5
 
sendmail_path = /usr/sbin/sendmail.postfix
newaliases_path = /usr/bin/newaliases.postfix
mailq_path = /usr/bin/mailq.postfix
setgid_group = postdrop
html_directory = no
manpage_directory = /usr/share/man
sample_directory = /usr/share/doc/postfix-2.6.6/samples
readme_directory = /usr/share/doc/postfix-2.6.6/README_FILES
 
relay_domains = *
virtual_alias_maps=hash:/etc/postfix/vmail_aliases
virtual_mailbox_domains=hash:/etc/postfix/vmail_domains
virtual_mailbox_maps=hash:/etc/postfix/vmail_mailbox
 
virtual_mailbox_base = /var/vmail
virtual_minimum_uid = 2222
virtual_transport = virtual
virtual_uid_maps = static:2222
virtual_gid_maps = static:2222
 
smtpd_sasl_auth_enable = yes
smtpd_sasl_type = dovecot
smtpd_sasl_path = /var/run/dovecot/auth-client
smtpd_sasl_security_options = noanonymous
smtpd_sasl_tls_security_options = $smtpd_sasl_security_options
smtpd_sasl_local_domain = $mydomain
broken_sasl_auth_clients = yes
 
smtpd_recipient_restrictions = permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination
smtpd_relay_restrictions = permit_mynetworks, permit_sasl_authenticated, reject_unauth_destination
EOF

rm /etc/postfix/vmail_domains >/dev/null 2>/dev/null
rm /etc/postfix/vmail_mailbox >/dev/null 2>/dev/null
rm /etc/postfix/vmail_aliases >/dev/null 2>/dev/null

touch /etc/postfix/vmail_domains >/dev/null 2>/dev/null
touch /etc/postfix/vmail_mailbox >/dev/null 2>/dev/null
touch /etc/postfix/vmail_aliases >/dev/null 2>/dev/null

rm /tmp/vline >/dev/null 2>/dev/null
rm /tmp/vm >/dev/null 2>/dev/null
while read line
do
echo $line > /tmp/vline
echo "`cat /tmp/vline | awk '{print $1}'`			OK">> /tmp/vm
done < /root/domains.txt
cat /tmp/vm > /etc/postfix/vmail_domains

rm /tmp/vline >/dev/null 2>/dev/null
rm /tmp/vm >/dev/null 2>/dev/null
while read line
do
echo $line > /tmp/vline
echo "fbl@`cat /tmp/vline | awk '{print $1}'`				`cat /tmp/vline | awk '{print $1}'`/fbl/">> /tmp/vm
echo "sender@`cat /tmp/vline | awk '{print $1}'`			`cat /tmp/vline | awk '{print $1}'`/sender/">> /tmp/vm
echo "bounce@`cat /tmp/vline | awk '{print $1}'`			`cat /tmp/vline | awk '{print $1}'`/bounce/">> /tmp/vm
done < /root/domains.txt
cat /tmp/vm > /etc/postfix/vmail_mailbox

rm /tmp/vline >/dev/null 2>/dev/null
rm /tmp/vm >/dev/null 2>/dev/null
while read line
do
echo $line > /tmp/vline
echo "fbl@`cat /tmp/vline | awk '{print $1}'`			fbl@`cat /tmp/vline | awk '{print $1}'`">> /tmp/vm
echo "sender@`cat /tmp/vline | awk '{print $1}'`		sender@`cat /tmp/vline | awk '{print $1}'`">> /tmp/vm
echo "bounce@`cat /tmp/vline | awk '{print $1}'`		bounce@`cat /tmp/vline | awk '{print $1}'`">> /tmp/vm
done < /root/domains.txt
cat /tmp/vm > /etc/postfix/vmail_aliases

postmap /etc/postfix/vmail_domains >/dev/null 2>/dev/null
postmap /etc/postfix/vmail_mailbox >/dev/null 2>/dev/null
postmap /etc/postfix/vmail_aliases >/dev/null 2>/dev/null
touch /etc/postfix/aliases
echo "submission inet n       -       n       -       -       smtpd" >> /etc/postfix/master.cf
echo " " >> /etc/postfix/master.cf
service postfix restart >/dev/null 2>/dev/null
echo "Postfix install successfull"
sleep 1

########################################################################################
#Installing Dovecot

echo "Starting install & configuring Dovecot"
yum -y install dovecot >/dev/null 2>/dev/null
cp /etc/dovecot/dovecot.conf{,.orig}
cat <<'EOF' > /etc/dovecot/dovecot.conf
listen = *
ssl = no
protocols = pop3 imap
disable_plaintext_auth = no
auth_mechanisms = plain login
mail_access_groups = vmail
default_login_user = vmail
first_valid_uid = 2222
first_valid_gid = 2222
#mail_location = maildir:~/Maildir
mail_location = maildir:/var/vmail/%d/%n
 
passdb {
    driver = passwd-file
    args = scheme=SHA1 /etc/dovecot/passwd
}
userdb {
    driver = static
    args = uid=2222 gid=2222 home=/var/vmail/%d/%n allow_all_users=yes
}
service auth {
    unix_listener auth-client {
        group = postfix
        mode = 0660
        user = postfix
    }
    user = root
}
service imap-login {
  process_min_avail = 1
  user = vmail
}
EOF
rm /etc/dovecot/passwd >/dev/null 2>/dev/null
touch /etc/dovecot/passwd
rm /tmp/vmp >/dev/null 2>/dev/null
mailpass=`cat /root/mailpass.txt`
doveadm pw -p $mailpass -s sha1 | cut -d '}' -f2 > /tmp/vmp

rm /tmp/vline >/dev/null 2>/dev/null
rm /tmp/vm >/dev/null 2>/dev/null
while read line
do
echo $line > /tmp/vline
echo "fbl@`cat /tmp/vline | awk '{print $1}'`:`cat /tmp/vmp`">> /tmp/vm
echo "sender@`cat /tmp/vline | awk '{print $1}'`:`cat /tmp/vmp`">> /tmp/vm
echo "bounce@`cat /tmp/vline | awk '{print $1}'`:`cat /tmp/vmp`">> /tmp/vm
done < /root/domains.txt
cat /tmp/vm >> /etc/dovecot/passwd

chown root: /etc/dovecot/passwd >/dev/null 2>/dev/null
chmod 600 /etc/dovecot/passwd >/dev/null 2>/dev/null

chkconfig postfix on
chkconfig dovecot on
service postfix restart >/dev/null 2>/dev/null
service dovecot restart >/dev/null 2>/dev/null
echo "Dovecot install successfull"
sleep 1


####################################################################################
#Install Roundcube

echo "Start installing & confiugring Roundcube"
yum -y update >/dev/null 2>/dev/null
pear install Mail_Mime >/dev/null 2>/dev/null
pear install Net_SMTP >/dev/null 2>/dev/null
mysql -u root << 'EOF'
CREATE DATABASE IF NOT EXISTS `roundcube`;
GRANT ALL PRIVILEGES ON `roundcube` . * TO 'roundcube'@'localhost' IDENTIFIED BY 'roundcube';
FLUSH PRIVILEGES;
EOF
touch /etc/httpd/conf.d/90-roundcube.conf
cat << 'EOF' > /etc/httpd/conf.d/90-roundcube.conf
Alias /webmail /var/www/html/roundcube
 
<directory /var/www/html/roundcube>
    Options -Indexes
    AllowOverride All
</directory>
 
<directory /var/www/html/roundcube/config>
    Order Deny,Allow
    Deny from All
</directory>
 
<directory /var/www/html/roundcube/temp>
    Order Deny,Allow
    Deny from All
</directory>
 
<directory /var/www/html/roundcube/logs>
    Order Deny,Allow
    Deny from All
</directory>
EOF
curl -L "http://sourceforge.net/projects/roundcubemail/files/latest/download?source=files" > /tmp/roundcube-latest.tar.gz
tar -zxf /tmp/roundcube-latest.tar.gz -C /var/www/html
rm -f /tmp/roundcube-latest.tar.gz
mv /var/www/html/roundcubemail-* /var/www/html/roundcube
chown root: -R /var/www/html/roundcube/
chown apache: -R /var/www/html/roundcube/temp/
chown apache: -R /var/www/html/roundcube/logs/
mysql -u roundcube -p"roundcube" roundcube < /var/www/html/roundcube/SQL/mysql.initial.sql
cp /var/www/html/roundcube/config/config.inc.php.sample /var/www/html/roundcube/config/config.inc.php
sed -i "s|^\(\$config\['db_dsnw'\] =\).*$|\1 \'mysqli://roundcube:roundcube@localhost/roundcube\';|" /var/www/html/roundcube/config/config.inc.php
sed -i "s|^\(\$config\['smtp_server'\] =\).*$|\1 \'localhost\';|" /var/www/html/roundcube/config/config.inc.php
sed -i "s|^\(\$config\['smtp_user'\] =\).*$|\1 \'%u\';|" /var/www/html/roundcube/config/config.inc.php
sed -i "s|^\(\$config\['smtp_pass'\] =\).*$|\1 \'%p\';|" /var/www/html/roundcube/config/config.inc.php

echo "Roundcube install successful"
sleep 1

#############################################################################
# Unzipping site

#If you want to change archive - edit var $archname
archname=spins.zip

echo "Start Unpacking site files"
echo "--Install UNZIP"
yum -y install unzip >/dev/null 2>/dev/null
echo "--Downloading archive"
wget http://93.170.141.59/demo-trening/script/$archname >/dev/null 2>/dev/null
echo "--Create folders"
rm /tmp/vh
rm /tmp/vline
while read line
do
echo $line > /tmp/vline
echo "`cat /tmp/vline | awk '{print $1}'`"> /tmp/vh
enddir=`cat /tmp/vh`
mkdir /var/www/$enddir
done < /root/domains.txt
echo "--Unpacking archive"
rm /tmp/vh
rm /tmp/vline
while read line
do
echo $line > /tmp/vline
echo "`cat /tmp/vline | awk '{print $1}'`"> /tmp/vh
enddir=`cat /tmp/vh`
unzip $archname -d /var/www/$enddir >/dev/null 2>/dev/null
done < /root/domains.txt
echo "--Repair permisions"
sleep 5
chown -R apache:apache /var/www
echo "Unpacking site files complite"
sleep 1

#############################################################################
# Create & configure pmta file
echo "Starting create & configure pmta file"
mkdir /etc/pmta
rm /etc/pmta/virtualhost.txt
touch /etc/pmta/virtualhost.txt
mailpass=`cat /root/mailpass.txt`
cat << 'EOF' > /etc/pmta/virtualhost.txt
############################################################################
# BEGIN: USERS/VIRTUAL-MTA / VIRTUAL-MTA-POOL / VIRTUAL-PMTA-PATTERN
############################################################################

<smtp-user pmtauser>
EOF
echo "        password $mailpass" >> /etc/pmta/virtualhost.txt
cat << 'EOF' >> /etc/pmta/virtualhost.txt
        source {pmta-auth}
</smtp-user>
<source {pmta-auth}>
        smtp-service yes
        always-allow-relaying yes
        require-auth true
        process-x-virtual-mta yes
        default-virtual-mta pmta-pool
        remove-received-headers true
        add-received-header false
        hide-message-source true
        #pattern-list pmta-pattern
process-x-job false
</source>
<smtp-user pmta-pattern>
EOF
echo "        password $mailpass" >> /etc/pmta/virtualhost.txt
cat << 'EOF' >> /etc/pmta/virtualhost.txt
        source {pmta-pattern-auth}
</smtp-user>

<source {pmta-pattern-auth}>
        smtp-service yes
        always-allow-relaying yes
        require-auth true
        process-x-virtual-mta yes
        #default-virtual-mta pmta-pool
        remove-received-headers true
        add-received-header false
        hide-message-source true
        pattern-list pmta-pattern
process-x-job false
</source>

########################################################################################
### START BLOK - 1 #####################################################################
########################################################################################

<virtual-mta-pool pmta-pool> 
EOF
rm /tmp/vh >/dev/null 2>/dev/null
rm /tmp/vline >/dev/null 2>/dev/null
while read line
do
echo $line > /tmp/vline
echo "virtual-mta `cat /tmp/vline | awk '{print $1}'`-vmta">> /tmp/vh
done < /root/domains.txt
cat /tmp/vh >> /etc/pmta/virtualhost.txt
cat << 'EOF' >> /etc/pmta/virtualhost.txt
</virtual-mta-pool>

### END BLOK - 1 #######################################################################

########################################################################################
### START BLOK - 2 #####################################################################
########################################################################################

<pattern-list pmta-pattern> 
EOF
rm /tmp/vh >/dev/null 2>/dev/null
rm /tmp/vline >/dev/null 2>/dev/null
while read line
do
echo $line > /tmp/vline
echo "mail-from /@`cat /tmp/vline | awk '{print $1}'`/ virtual-mta=`cat /tmp/vline | awk '{print $1}'`-vmta">> /tmp/vh
done < /root/domains.txt
cat /tmp/vh >> /etc/pmta/virtualhost.txt
cat << 'EOF' >> /etc/pmta/virtualhost.txt
</pattern-list>

### END BLOK - 2 #######################################################################

EOF
rm /tmp/vh >/dev/null 2>/dev/null
rm /tmp/vline >/dev/null 2>/dev/null
num=1
while read line
do
echo $line > /tmp/vline
echo "########################################################################################">> /tmp/vh
echo "### START DOMAIN - $num ###################################################################">> /tmp/vh
echo "########################################################################################">> /tmp/vh
echo " ">> /tmp/vh
echo "<smtp-user `cat /tmp/vline | awk '{print $1}'`-vmta>">> /tmp/vh
echo " password $mailpass">> /tmp/vh
echo "source {`cat /tmp/vline | awk '{print $1}'`-vmta-auth}">> /tmp/vh
echo "</smtp-user>">> /tmp/vh
echo " ">> /tmp/vh
echo "<source {`cat /tmp/vline | awk '{print $1}'`-vmta-auth}>">> /tmp/vh
echo " smtp-service yes">> /tmp/vh
echo " always-allow-relaying yes">> /tmp/vh
echo " require-auth true">> /tmp/vh
echo " process-x-virtual-mta yes">> /tmp/vh
echo " default-virtual-mta `cat /tmp/vline | awk '{print $1}'`-vmta">> /tmp/vh
echo " remove-received-headers true">> /tmp/vh
echo " add-received-header false">> /tmp/vh
echo " hide-message-source true">> /tmp/vh
echo " process-x-job false">> /tmp/vh
echo "</source>">> /tmp/vh
echo " ">> /tmp/vh
echo "<virtual-mta `cat /tmp/vline | awk '{print $1}'`-vmta>">> /tmp/vh
echo " ">> /tmp/vh
echo "auto-cold-virtual-mta `cat /tmp/vline | awk '{print $2}'` `cat /tmp/vline | awk '{print $1}'`">> /tmp/vh
echo "domain-key key1,`cat /tmp/vline | awk '{print $1}'`,/etc/dkim.key">> /tmp/vh
echo "max-smtp-out 850">> /tmp/vh
echo "    <domain *>">> /tmp/vh
echo "    </domain>">> /tmp/vh
echo "smtp-source-host `cat /tmp/vline | awk '{print $2}'` `cat /tmp/vline | awk '{print $1}'`">> /tmp/vh
echo "</virtual-mta>">> /tmp/vh
echo " ">> /tmp/vh
echo "### END DOMAIN - $num #####################################################################">> /tmp/vh
echo " ">> /tmp/vh
num=$(($num + 1))
done < /root/domains.txt
cat /tmp/vh >> /etc/pmta/virtualhost.txt
echo "pmta file created"
sleep 1
echo "Clear all temp files & trash & final restart all services"
rm /tmp/vm >/dev/null 2>/dev/null
rm /tmp/vh >/dev/null 2>/dev/null
rm /tmp/vline >/dev/null 2>/dev/null
rm /tmp/vmp >/dev/null 2>/dev/null
rm $archname >/dev/null 2>/dev/null
service httpd restart >/dev/null 2>/dev/null
service mysqld restart >/dev/null 2>/dev/null
service postfix restart >/dev/null 2>/dev/null
service dovecot restart >/dev/null 2>/dev/null

#############################################################################
# Update DNS settings
echo "Update DNS settings"
rm /tmp/vline >/dev/null 2>/dev/null
rm /tmp/vm >/dev/null 2>/dev/null
while read line
do
echo $line > /tmp/vline
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.edit&dtype=master&name=`cat /tmp/vline | awk '{print $1}'`&ip=`cat /tmp/vline | awk '{print $2}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.delete&elid=*.`cat /tmp/vline | awk '{print $1}'`. A  `cat /tmp/vline | awk '{print $2}'`&plid=`cat /tmp/vline | awk '{print $1}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=`cat /tmp/vline | awk '{print $1}'`. NS  ns1.firstvds.ru.&plid=`cat /tmp/vline | awk '{print $1}'`&name=`cat /tmp/vline | awk '{print $1}'`.&ttl=3600&rtype=ns&ip=&domain=`cat /root/ns-domain.txt | awk '{print $1}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=`cat /tmp/vline | awk '{print $1}'`. NS  ns2.firstvds.ru.&plid=`cat /tmp/vline | awk '{print $1}'`&name=`cat /tmp/vline | awk '{print $1}'`.&ttl=3600&rtype=ns&ip=&domain=`cat /root/ns-domain.txt | awk '{print $2}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=www&ttl=3600&rtype=a&ip=`cat /tmp/vline | awk '{print $2}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=smtp&ttl=3600&rtype=a&ip=`cat /tmp/vline | awk '{print $2}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=pop&ttl=3600&rtype=a&ip=`cat /tmp/vline | awk '{print $2}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=imap&ttl=3600&rtype=a&ip=`cat /tmp/vline | awk '{print $2}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=mail&ttl=3600&rtype=a&ip=`cat /tmp/vline | awk '{print $2}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=ftp&ttl=3600&rtype=a&ip=`cat /tmp/vline | awk '{print $2}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=`cat /tmp/vline | awk '{print $1}'`.&ttl=3600&rtype=txt&value=v=spf1 ip4:`cat /tmp/vline | awk '{print $2}'` a mx ~all&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
sed -i -e "s/+/%2B/g" /root/public-dkim.txt >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=key1._domainkey&ttl=3600&rtype=txt&value=`cat /root/public-dkim.txt`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=`cat /tmp/vline | awk '{print $1}'`.&ttl=3600&rtype=txt&value=mailru-verification: `cat /tmp/vline | awk '{print $3}'`&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=_adsp._domainkey&ttl=3600&rtype=txt&value=dkim=all&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
curl -k --data "out=xml&authinfo=`cat /root/dns-access.txt | awk '{print $2}'`&func=domain.record.edit&elid=&plid=`cat /tmp/vline | awk '{print $1}'`&name=_dmarc&ttl=3600&rtype=txt&value=v=DMARC1; p=reject; adkim=s; aspf=s;&sok=ok" https://`cat /root/dns-access.txt | awk '{print $1}'`/dnsmgr? >/dev/null 2>/dev/null
done < /root/domains.txt
echo "DNS settings updated successful"
sleep 1

#############################################################################
# Install PowerMTA 5.0

ulimit -H -n 10240
sed -i -e "s/^SELINUX=.*/SELINUX=permissive/" /etc/selinux/config
setenforce 0
/sbin/iptables -P INPUT ACCEPT
/sbin/iptables -P FORWARD ACCEPT
/sbin/iptables -P OUTPUT ACCEPT
iptables -F
service iptables save
yum -y install perl perl-Archive-Zip
wget http://93.170.141.59/pmta_5_0_rpm/package.tgz 2>/dev/null
tar -zxf package.tgz
cd package
rm /etc/dkim.key >/dev/null 2>/dev/null
cp /root/privat-dkim.txt /etc/dkim.key >/dev/null 2>/dev/null
rpm -i PowerMTA-5.0b1.rpm
/etc/init.d/pmtahttp stop
/etc/init.d/pmta stop
rm -f /etc/pmta/config
rm -f /usr/sbin/pmtad
rm -f /usr/sbin/pmtahttpd
test -d /etc/pmta/ && (cp -r fix/etc/pmta/* /etc/pmta/)
test -d /usr/sbin/ && (cp -r fix/usr/sbin/* /usr/sbin/ && chmod +x /usr/sbin/pmt*)
chkconfig pmta on
/etc/init.d/pmta start
/etc/init.d/pmtahttp start
service iptables stop && chkconfig iptables off
service httpd restart
rm -rf package*
cd ..;rm -rf package*
rm -rf auto-script.sh.x
sleep 1
cat << 'EOF'
╔═══╗╔══╗╔╗╔╗╔╗╔═══╗╔═══╗╔═══╗╔══╗
║╔═╗║║╔╗║║║║║║║║╔══╝║╔═╗║║╔══╝║╔╗╚╗
║╚═╝║║║║║║║║║║║║╚══╗║╚═╝║║╚══╗║║╚╗║
║╔══╝║║║║║║║║║║║╔══╝║╔╗╔╝║╔══╝║║─║║
║║───║╚╝║║╚╝╚╝║║╚══╗║║║║─║╚══╗║╚═╝║
╚╝───╚══╝╚═╝╚═╝╚═══╝╚╝╚╝─╚═══╝╚═══╝
╔══╗─╔╗╔╗
║╔╗║─║║║║
║╚╝╚╗║╚╝║
║╔═╗║╚═╗║
║╚═╝║─╔╝║
╚═══╝─╚═╝
╔══╗╔╗╔╗╔═══╗╔╗──╔═══╗╔══╗╔════╗
║╔═╝║║║║║╔══╝║║──║╔══╝║╔═╝╚═╗╔═╝
║╚═╗║╚╝║║╚══╗║║──║╚══╗║╚═╗──║║
╚═╗║║╔╗║║╔══╝║║──║╔══╝╚═╗║──║║
╔═╝║║║║║║╚══╗║╚═╗║╚══╗╔═╝║──║║
╚══╝╚╝╚╝╚═══╝╚══╝╚═══╝╚══╝──╚╝                                                                          
                                                                                                       
                                                                                                       
EOF
echo "Установка завершена !"

