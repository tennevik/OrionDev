﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head>
    <title>Вы успешно отписались от нашей рассылки</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="description" content="This is a default index page for a new domain."/>
</head>

<body>
<?php
    $myCurl = curl_init();
  curl_setopt_array($myCurl, array(
      CURLOPT_URL => 'http://xspamer.com/interface/unscribestat.ashx?',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_POST => true,
      CURLOPT_POSTFIELDS => http_build_query($_GET)
  ));
  $result = curl_exec($myCurl);
  echo $result;
?>
<table align="center" height="00">
<tr height ="200">
    <td></td>
</tr>
<tr height="300" valign="top">
    <td>
        <h1>Вы успешно отписались от нашей рассылки!</h1>
        
    </td>
</tr>
<tr>
    <td align="center">
        <a href="[URL]">Сервис электронных рассылок</a>
    </td>
</tr>

</table>
</body>

</html>

